package com.example.projectdemo.data.remote.model


data class VideoModel(
    val id: Int,
    val results: List<VideoModelClass>
)

