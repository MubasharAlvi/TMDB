package com.example.projectdemo.data.remote.model

data class VideoModelClass(
    val name: String,
    val key : String,
    val site : String,
    val size: Int,
    val id:String
)
