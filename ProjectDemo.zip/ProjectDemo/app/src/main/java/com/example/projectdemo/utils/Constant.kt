package com.example.projectdemo.utils

object Constant {
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val API_KEY = "15bfad0090cb7eec31022ab8ccf17dd3"
    const val URL_IMAGE: String = "https://image.tmdb.org/t/p/w500"
    const val URL_YouTUBE: String = "https://www.youtube.com/watch?v="
}